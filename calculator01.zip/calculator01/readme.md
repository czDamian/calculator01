This is a simple calculator.
Feel free to look at you as you try to make your own better